from groq import Groq
import os
import logging
from typing import List
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(level=logging.INFO)

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "").strip()

client = None
if GROQ_API_KEY:
    try:
        client = Groq(api_key=GROQ_API_KEY)
    except Exception as e:
        logging.warning(f"Groq init failed: {e}")
        client = None

# ================= TEXT CHUNKING =================
def split_text(text: str, chunk_size: int = 1500) -> List[str]:
    """Split text into safe chunks."""
    return [text[i:i + chunk_size] for i in range(0, len(text), chunk_size)]



# ================= FALLBACK =================
def basic_summary(text: str) -> str:
    """Fallback summary if API fails."""
    sentences = text.split(".")
    return ". ".join(sentences[:3]).strip() + "..." if len(sentences) > 3 else text


def basic_keypoints(text: str) -> str:
    """Fallback key points extraction."""
    lines = text.split("\n")
    return "\n".join(f"• {line}" for line in lines[:5] if line.strip())


# ================= SUMMARIZE =================
def summarize_text(text: str) -> str:
    if not isinstance(text, str) or not text.strip():
        return "⚠ No valid text provided"

    if client is None:
        return basic_summary(text)

    chunks = split_text(text)
    summaries = []

    for chunk in chunks:
        prompt = f"""
Summarize the following text clearly and concisely.

TEXT:
{chunk}
"""

        try:
            response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=300
            )

            content = response.choices[0].message.content
            summaries.append(content.strip() if content else "")

        except Exception as e:
            logging.error(f"Summarization error: {e}")
            summaries.append(basic_summary(chunk))

    return "\n".join(summaries)


# ================= KEY POINTS =================
def extract_key_points(text: str) -> str:
    if not isinstance(text, str) or not text.strip():
        return "⚠ No valid text provided"

    if client is None:
        return basic_keypoints(text)

    chunks = split_text(text)
    all_points = []

    for chunk in chunks:
        prompt = f"""
Extract key points from the text.

Return bullet points only.

TEXT:
{chunk}
"""

        try:
            response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=300
            )

            content = response.choices[0].message.content
            all_points.append(content.strip() if content else "")

        except Exception as e:
            logging.error(f"Key point extraction error: {e}")
            all_points.append(basic_keypoints(chunk))

    return "\n".join(all_points)